<td class="position-static">
    <div class="row__selection">
        <input type="checkbox" class="form-check-input position-relative mx-2" id="check">
        <label for="check"></label>
    </div>
</td>
<td>29103050</td>
<td>
    11081197
</td>
<td>58276066</td> 
<td>Nguyen Shane</td>
<td>
    Afghanistan
</td>
<td>Male</td> 
<td>02/12/2000 <span class="fw-bold">(25)</span></td>
<td>Tandeem</td>
<td>10/12/2024 <span class="fw-bold">(E-Waiver)</span></td>
<td>09/12/2025</td>
<td>
    <div class="badge bg-success">Valid</div>
</td> 
<td>
    <div class="d-inline-flex gap-2">
        <button class="btn ac__btn btn-primary p-0" type="button"
             data-bs-toggle="offcanvas" data-bs-target="#offcanvasAuditDetail" aria-controls="offcanvasAuditDetail"
        > 
            <svg width="20" height="20" fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><g clip-path="url(#a)" stroke="#fff" stroke-width="1.667" stroke-linecap="round" stroke-linejoin="round"><path d="M.833 10S4.167 3.333 10 3.333 19.167 10 19.167 10 15.833 16.666 10 16.666.833 10 .833 10"/><path d="M10 12.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5"/></g><defs><clipPath id="a"><path fill="#fff" d="M0 0h20v20H0z"/></clipPath></defs></svg>
        </button> 
    </div>
</td>
 


